CREATE VIEW modifier_with_stats_and_translations AS
SELECT
    m.id AS modifier_id,
    m.name AS modifier_name,
    ms.min AS min_value,
    ms.max AS max_value,
    st.string AS translation
FROM
    modifiers m
JOIN
    modifier_stats ms ON m.id = ms.modifier_id
JOIN
    stat_translations st ON ms.stat_id = st.id;

